# Salesforce Outbound Message Handler

Java REST web service.

Listens for outbound messages from Salesforce.
Parses the outbound message for action context.
Calls a REST web service hosted on Salesforce, passing the Salesforce object Id.
